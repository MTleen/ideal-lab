---
name: technical-proposal-writing
description: This skill should be used when users need to write professional technical proposals, bid documents, or technical design schemes. It provides a structured 6-phase workflow for requirement analysis, technology research, document structuring, content writing, diagram creation, and quality review. The skill ensures detailed technical solutions with justified technology choices, professional document structure, and compliance with evaluation criteria.
---

# Technical Proposal Writing Expert

## Overview

This skill enables the creation of professional-grade technical proposals that excel in competitive bidding scenarios. It transforms user requirements into comprehensive technical documents with justified technology selections, system architecture diagrams, implementation roadmaps, and persuasive technical narratives.

## When to Use This Skill

Use this skill when users request:
- Technical proposals for government or enterprise procurement
- Bid documents for project competitions
- Technical design schemes for funding applications
- Responses to RFPs (Request for Proposals)
- Technical white papers or solution documents
- Detailed implementation plans for complex projects

**Trigger phrases:** "write a technical proposal", "create a bid document", "technical design scheme", "respond to RFP", "project proposal"

## 6-Phase Workflow

### Phase 1: Requirement Analysis
Extract and analyze all requirements from tender documents or user specifications.

**Process:**
1. Request the tender document or detailed requirements
2. Extract functional requirements with keywords
3. Identify evaluation criteria and scoring weights
4. Recognize implicit requirements (diagrams, timelines, risks)
5. Categorize by priority (must-have, should-have, nice-to-have)
6. Generate clarification questions for unknown aspects

**Output:** Requirement checklist, evaluation criteria mapping, knowledge gaps

### Phase 2: Technical Research
Research and select mature, proven technologies for each requirement.

**Process:**
1. For each technical requirement, research 2-3 technology options
2. Evaluate based on maturity, performance, integration, cost, support
3. Verify technology compatibility across the stack
4. Document selection rationale with specific reasons
5. Create technology stack coherence analysis
6. Prepare integration architecture sketch

**Output:** Technology selection matrix, justification documentation, stack diagram

### Phase 3: Document Structure Design
Design a logical, reader-friendly document structure aligned with evaluation criteria.

**Process:**
1. Create markdown outline based on requirements order
2. Allocate word counts by section importance
3. Plan diagram placements and types
4. Design section hierarchy for readability
5. Ensure coverage of all evaluation criteria
6. Review structure against tender requirements

**Output:** Document outline, section word counts, visual element plan

### Phase 4: Content Writing
Write each section using proven patterns with appropriate depth and professionalism.

**Process:**
1. **Project Overview**: Write compelling value proposition (200-300 words)
2. **Technical Solutions**: Apply What-Why-How pattern for each requirement
3. **System Architecture**: Describe layered architecture with specific technologies
4. **Implementation Roadmap**: Create 5-phase timeline with tasks and deliverables
5. **Questions for Clarification**: Generate professional, thoughtful questions
6. **Solution Advantages**: Summarize technical, economic, and innovation benefits

**Writing Guidelines:**
- Use specific technology names with versions (e.g., "PostgreSQL 14", not "database")
- Apply What-Why-How pattern: What it is → Why chosen → How implemented → Benefits
- Write in flowing paragraphs, not bullet points or tables
- Include quantitative evidence (specific numbers, metrics, comparisons)
- Maintain professional yet accessible tone

### Phase 5: Diagram Creation
Create professional architecture diagrams and implementation roadmaps in DrawIO format.

**Architecture Diagram Requirements:**
- Layer-based layout with clear separation
- Specific technology names in each component
- Data flow arrows with protocol/format labels
- Consistent color scheme per layer
- Brief component descriptions

**Implementation Roadmap Requirements:**
- Timeline showing 5 phases with durations
- 3-7 key tasks per phase
- Deliverables clearly listed
- Key technologies section
- Expected outcomes summary

**Process:**
1. Create architecture diagram with proper layering
2. Develop implementation roadmap with timeline
3. Ensure diagram-text alignment
4. Export preview images for reference
5. Save in DrawIO XML format

### Phase 6: Global Review
Ensure completeness, consistency, and quality before delivery.

**Review Checklist:**
- **Completeness**: All requirements covered, diagrams included, sections complete
- **Consistency**: Technology names consistent, diagrams match text, terminology uniform
- **Quality**: No typos, appropriate paragraph length, sufficient technical detail
- **Evaluation Criteria**: Detailed, feasible, rational, complete as per scoring guidelines

## Writing Patterns

### What-Why-How Pattern
```
我们将采用[Technology]。
[Technology]是一种[Definition]。
我们选择它是因为[Reason 1]、[Reason 2]和[Reason 3]。
在实现上，我们将[Implementation Details]。
这种方案的优势在于[Advantage 1]和[Advantage 2]。
```

### Comparison Pattern
```
传统方法：[Traditional Approach] + [Limitations]
本方案：[Our Approach] + [Advantages]
对比结果：[Quantitative Comparison]
```

### Layered Architecture Pattern
```
整体架构：[High-level overview]
第一层：[Layer 1] - [Function] - [Technology]
第二层：[Layer 2] - [Function] - [Technology]
层间交互：[How layers interact]
```

## Resources

This skill includes comprehensive resources organized into three categories:

### references/
Comprehensive documentation and reference material for informed proposal writing:

- **writing_patterns.md**: Complete library of writing techniques with examples
- **document_templates.md**: Standard document structures for different proposal types
- **quality_checklists.md**: Detailed checklists for each phase and review criteria
- **diagram_guidelines.md**: Design guidelines for creating professional architecture diagrams and roadmaps

Load these references as needed when working on specific aspects of the proposal.

### assets/
Templates and example files for generating professional outputs:

- **proposal_template.md**: Complete markdown template for technical proposals

Use this template as a starting point and customize for specific projects. Do not load into context - copy and modify as needed.

## Pro Tips

1. **Always Start with Questions**: Never assume critical requirements. Ask clarifying questions in Phase 1.
2. **Be Specific About Technologies**: Use exact names and versions (e.g., "Apache Kafka 3.2", not just "messaging system").
3. **Align with Evaluation Criteria**: Structure content to directly address how the proposal will be scored.
4. **Use Quantitative Evidence**: Replace vague claims with specific numbers and metrics.
5. **Iterate Section by Section**: Review and refine each section before moving to the next.
6. **Ensure Diagram-Text Consistency**: Diagrams must exactly match the technical descriptions.

## Expected Deliverables

When using this skill, always deliver:
1. **Main Proposal Document**: 4000-6000 words in markdown format
2. **Architecture Diagram**: DrawIO XML file showing system architecture
3. **Implementation Roadmap**: DrawIO XML file showing timeline and phases
4. **Clarification Questions**: List of professional questions for client

## Quality Standards

- **Detail Level**: Core technologies explained thoroughly (600-900 words), supporting elements concise (300-500 words)
- **Technology Maturity**: All selected technologies must be production-ready with specific versions
- **Justification**: Every technical choice must be explicitly justified with clear reasoning
- **Completeness**: All tender requirements covered, no gaps or omissions
- **Professionalism**: No typos, consistent terminology, appropriate technical depth